"""Gray-Matter MCP server — proxy + orchestrator.

Runs as a stdio MCP server that:
1. Accepts tool calls from the client
2. Routes them to the right registered MCP server (Neuron, NeuRAG)
3. Returns the response to the client
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import socket
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from mcp.server.lowlevel import Server
from mcp.server.models import InitializationOptions
from mcp.types import Tool, TextContent

from gray_matter import __version__
from gray_matter.cache import ContextCache
from gray_matter.registry import Registry
from gray_matter import settings as _settings

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Tunable knobs (see `gray-matter config`): read once at startup — `config set`
# takes effect on the next restart. Missing/unknown keys fall back to defaults.
_cfg = _settings.load()

# SSOT in cli.py: la CLI (e la GUI) devono conoscere host/porta SENZA
# importare questo modulo, che trascina `mcp` e tutto il server.
# _send_ipc/_recv_exact vivono in cli.py con host e porta (stesso SSOT). Qui ne
# esisteva una COPIA sincrona, resa irraggiungibile dall'omonima `async
# _recv_exact` definita più sotto: Python risolve i globali alla chiamata, così
# `_send_ipc` finiva per invocare la coroutine con 2 argomenti su 3 →
# TypeError. Effetto: _send_heartbeat/_send_registration fallivano SEMPRE →
# NeuRAG standalone moriva all'avvio (autoregister non è protetto) e Neuron non
# si registrava mai al gateway, in silenzio. Una copia sola, importata.
from gray_matter.cli import (GRAY_MATTER_HOST, GRAY_MATTER_PORT,  # noqa: E402
                             GRAY_MATTER_PORT_SPAN, resolve_port, write_port_file,
                             clear_port_file, port_is_free, gm_answers,
                             _send_ipc, IPC_TOOL_TIMEOUT)
from gray_matter import ipcauth as _ipcauth  # noqa: E402
HEARTBEAT_INTERVAL = _cfg["heartbeat_interval"]  # seconds
HEARTBEAT_TIMEOUT = 15.0  # seconds — after 3 missed beats, mark dead
IDLE_SLEEP_TIMEOUT = _cfg["idle_sleep_timeout"]  # sleep after this long idle

# ---------------------------------------------------------------------------
# IPC helpers (tiny TCP-based protocol for server <-> Gray-Matter)
# ---------------------------------------------------------------------------

def _send_registration(name: str, tool_names: list[str], socket_path: str, pid: int) -> dict:
    """Register this server with Gray-Matter."""
    return _send_ipc({
        "action": "register",
        "name": name,
        "tool_names": tool_names,
        "socket_path": socket_path,
        "pid": pid,
    })


def _send_heartbeat(name: str) -> dict:
    """Send a heartbeat ping."""
    return _send_ipc({
        "action": "heartbeat",
        "name": name,
    })


def _is_gray_matter_running() -> bool:
    """True only when a GM actually answers on (host, port) (ping probe, not a
    blind TCP connect): the `port` file can be stale after a reboot, and a
    foreign listener on that port made start/ping say "already running" while
    every real IPC call failed."""
    return gm_answers(GRAY_MATTER_HOST, resolve_port())


def autoregister(name: str, tool_names: list[str]) -> bool:
    """Auto-register with a running Gray-Matter. Returns True on success.

    If Gray-Matter is not running, spawns one first.
    Then registers this server.
    """
    # Spawn Gray-Matter if not running
    if not _is_gray_matter_running():
        _spawn_gray_matter()

    # Register (retry up to 3 times — race with spawn)
    pid = os.getpid()
    socket_path = f"tcp://{GRAY_MATTER_HOST}:{os.getpid() + 50000}"  # dummy, placeholder
    for attempt in range(3):
        result = _send_registration(name, tool_names, socket_path, pid)
        if "error" not in result:
            return True
        time.sleep(0.3)
    return False


def daemon_log_path():
    """Il log del daemon (G2): stdout+stderr del processo finiscono qui."""
    from gray_matter.paths import logs_dir
    return logs_dir() / "daemon.log"


def _spawn_gray_matter() -> None:
    """Spawn Gray-Matter as a background process."""
    # Use python -m gray_matter.server to run the server module
    # Detach from parent process so it survives parent death
    cmd = [sys.executable, "-u", "-m", "gray_matter.server", "--daemon"]  # -u: log senza buffering
    creationflags = 0
    if sys.platform == "win32":
        # NIENTE DETACHED_PROCESS. Windows IGNORA CREATE_NO_WINDOW quando è
        # combinato con DETACHED_PROCESS (o CREATE_NEW_CONSOLE), e il figlio
        # staccato si alloca una console TUTTA SUA — la finestra CMD vuota che
        # compariva a ogni `gray-matter start`. Misurato sul posto:
        #   CREATE_NO_WINDOW | DETACHED_PROCESS -> console visibile
        #   CREATE_NO_WINDOW                    -> nessuna console
        #   CREATE_NO_WINDOW | NEW_PROCESS_GROUP-> nessuna console
        # DETACHED_PROCESS non serviva comunque a far sopravvivere il daemon:
        # su Windows i figli non muoiono col padre (non c'è kill dell'albero
        # senza un Job object). Il gruppo separato serve solo a NON prendere il
        # Ctrl-C della console che l'ha avviato.
        creationflags = (subprocess.CREATE_NO_WINDOW
                         | subprocess.CREATE_NEW_PROCESS_GROUP)

    # G2: stdout/stderr → logs/daemon.log (append) invece del buco nero — ogni
    # print e traceback diventa leggibile con `gray-matter logs [--follow]`.
    # Fallback DEVNULL se il file non è apribile (mai bloccare lo spawn).
    try:
        log_path = daemon_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        out = open(log_path, "a", encoding="utf-8", errors="replace")  # noqa: SIM115
        out.write(f"\n--- spawn {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        out.flush()
    except OSError:
        out = None
    stdout_err = out if out is not None else subprocess.DEVNULL
    try:
        subprocess.Popen(
            cmd,
            creationflags=creationflags,
            stdin=subprocess.DEVNULL,
            stdout=stdout_err,
            stderr=stdout_err,
        )
    finally:
        if out is not None:
            out.close()  # parent FD closed; child inherited it


# ---------------------------------------------------------------------------
# Gray-Matter MCP Server
# ---------------------------------------------------------------------------

_registry = Registry.instance()
_last_call_time: float = time.time()
_flash_counter: int = 0

# ONE shared context cache. It used to be re-created inside every pulse, so it
# never hit — a silent "cache that never caches" bug. A single instance persists
# across calls and makes `gray-matter stats` hit-rate meaningful.
_ctx_cache = ContextCache(max_size=_cfg["cache_max_size"], ttl=_cfg["cache_ttl_seconds"])

# Lightweight observability counters, surfaced by `gray-matter stats` / `doctor`.
_stats: dict[str, float] = {"pulses": 0, "cache_hits": 0, "cache_misses": 0,
                            "flashes": 0, "bridges_added": 0, "pulse_ms_total": 0.0,
                            "kb_hints": 0}
# Calls per tool this session (model-initiated only, not GM's internal
# lookups): how many knowledge_query a pointer provokes was a feeling until now.
_tool_calls: dict[str, int] = {}

# D4 — conversation buffer: gli ultimi topic della sessione. Ogni pulse espande
# la query NeuRAG col contesto recente (recall migliore su domande incrementali);
# Neuron non ne ha bisogno (ha già la sua context window interna).
from collections import deque as _deque
_topic_buffer: "_deque[str]" = _deque(maxlen=3)


def _remember_topic(topic: str) -> None:
    if topic in _topic_buffer:          # ri-chiesto → torna in cima
        _topic_buffer.remove(topic)
    _topic_buffer.append(topic)


# Flash v1: fire on a topic shift (serendipity at transitions), rate-limited.
_last_topic: str = ""
_flashed: set = set()          # concepts already flashed this session (cooldown)
_calls_since_flash: int = 0
FLASH_MIN_GAP = _cfg["flash_min_gap"]   # min pulses between flashes (anti-spam)

# Stimulus safety-net (design §Decisioni 3): il motore degli stimoli è di Neuron
# (piggyback 🧠 sui suoi tool); se l'LLM smette di far passare stimoli per N
# turni-tool, GM lo rilancia LUI sul prossimo pass-through. Toggle/tuning in
# settings (→ GUI Preferences): stimulus_safety_net / stimulus_safety_gap.
STIM_SAFETY_NET = _cfg["stimulus_safety_net"]
STIM_SAFETY_GAP = _cfg["stimulus_safety_gap"]
BRAINSTORM_HINT = _cfg["brainstorm_hint"]
_turns_since_stim: int = 0

# Quanto contesto GM inietta. Il punto del progetto è far RISPARMIARE token, e
# fino a qui la quantità era un effetto collaterale: il blocco proattivo (bridge,
# vicini, flash) non aveva alcun tetto, e 40 bridge che condividevano un tag
# facevano ~5000 token in una sola pulse. Ora è un budget, regolabile dalla GUI.
KNOWLEDGE_TOP_N = _cfg["knowledge_top_n"]
MEMORY_MAX_TOKENS = _cfg["memory_max_tokens"]
PROACTIVE_BUDGET = _cfg["proactive_budget_chars"]
# Quanti bridge al massimo per pulse. Non è un knob: il budget in caratteri è
# già la manopola: questo è solo la difesa che evita di RINFORZARE (e quindi
# promuovere) decine di bridge per poi scartarne il testo.
_BRIDGES_PER_PULSE = 5
# Quanto razionale mostrare per bridge. Lo store ne accetta 500 caratteri perché
# lì è documentazione che un umano legge in `gray-matter bridges`; iniettarli
# interi in una pulse voleva dire spendere il budget su cinque paragrafi.
_BRIDGE_WHY_CHARS = 80


async def _do_promote(apply: bool = False) -> dict:
    """CLS consolidation, dry run unless `apply` (§5.3, §8.2).

    Reads Neuron through its `export` tool and writes NeuRAG through
    `knowledge_add_node`: two public surfaces, no vault opened here.
    """
    import json as _json

    from gray_matter import promote as _promote

    try:
        raw = await _call_server_async("neuron", "export", {})
        export = _json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        return {"error": f"Neuron non raggiungibile o export illeggibile: {exc}"}

    cands = _promote.candidates(export)
    written, skipped, already, chunks_written = [], [], [], 0
    if apply and cands:
        # One godnode for everything that comes from memory: a `fundamental`
        # needs a parent (NeuRAG raises without one — the old apply never
        # wrote a single node), and the vault tree stays readable: the
        # ingested repo on one side, the promoted memory on the other.
        try:
            await _call_server_async("neurag", "knowledge_add_node", {
                "name": _promote.PROMOTE_PARENT, "node_type": "godnode",
                "triggers": ["memoria", "promosso", "promote", "neuron"]})
        except Exception as exc:  # noqa: BLE001 — "already exists" arrives as text, not as an error
            return {"error": f"godnode '{_promote.PROMOTE_PARENT}' non creabile: {exc}"}
        for c in cands:
            try:
                # The tags it already shares travel with it — that is what makes
                # a promotion a JOIN between the two graphs instead of an orphan
                # dropped into NeuRAG (§4).
                res = str(await _call_server_async("neurag", "knowledge_add_node", {
                    "name": c["keyword"], "node_type": "fundamental",
                    "parent_name": _promote.PROMOTE_PARENT,
                    "triggers": c["tags"] or [c["keyword"]],
                })).lower()
                if "already exists" in res:
                    # ponytail: a concept is promoted once; chunks have no dedup in
                    # NeuRAG, so re-applying must not re-add them. Episodes that
                    # arrive AFTER the promotion stay in Neuron: diff-and-append
                    # when a real case asks for it.
                    already.append(c["keyword"])
                    continue
                if "not found" in res:
                    skipped.append(c["keyword"])
                    continue
                written.append(c["keyword"])
                # The memory, not just the name: link rationales and episodes
                # become chunks, so knowledge_query can FIND the promoted concept
                # by the text of one of its facts. Before this a promoted node
                # was a bare label — no text, no embedding, never retrieved.
                if c.get("chunks"):
                    await _call_server_async("neurag", "knowledge_add_chunks", {
                        "node_name": c["keyword"], "chunks": c["chunks"]})
                    chunks_written += len(c["chunks"])
                # No bridge: the node carries the concept's own name, and
                # _kb_lookup resolves a pre_turn keyword by name — the name IS
                # the join (add_bridge refuses same-name endpoints anyway).
            except Exception as exc:  # noqa: BLE001 — un nodo rotto non ferma il resto
                skipped.append(f"{c['keyword']}: {exc}")
    return {"applied": apply, "count": len(cands), "candidates": cands,
            "written": written, "already": already, "skipped": skipped,
            "chunks": chunks_written, "rules": _promote.PROMOTE_RULES}


def _fit(budget: int, blocks: list[str]) -> tuple[str, int]:
    """Take blocks in priority order, keeping each that still fits in `budget`.

    Trims by BLOCK, never mid-sentence: half a bridge line costs the same
    context as a whole one and reads like a bug. Returns the joined text and how
    many blocks were dropped, so the caller can say so instead of the reader
    wondering.

    A block too big to fit is SKIPPED, not a stop signal — a later, smaller one
    still gets in. These are independent hints, so more of them inside the same
    budget is worth more than a strict prefix of the priority order."""
    kept, used, dropped = [], 0, 0
    for b in blocks:
        if not b:
            continue
        if used + len(b) > budget:
            dropped += 1
            continue
        kept.append(b)
        used += len(b)
    return "\n\n".join(kept), dropped


def _stim_seen(text: str) -> None:
    """Un pulse/risposta che già porta stimoli (🧠/⚡) azzera il contatore."""
    global _turns_since_stim
    if "🧠" in text or "⚡" in text:
        _turns_since_stim = 0


async def _safety_net_note(tool_name: str, arguments: dict, result: str) -> str:
    """Rete di sicurezza: '' quasi sempre; una riga 🧠 quando il piggyback tace
    da STIM_SAFETY_GAP turni. Best-effort, mai bloccante, anti-recursione (parla
    col worker Neuron direttamente, non ri-entra in call_tool)."""
    global _turns_since_stim
    if not STIM_SAFETY_NET:
        return ""
    if "🧠" in result or "⚡" in result:
        _turns_since_stim = 0                     # lo stimolo è passato: riposa
        return ""
    _turns_since_stim += 1
    if _turns_since_stim < STIM_SAFETY_GAP:
        return ""
    neuron = _registry.get_server("neuron")
    if not neuron or not neuron.is_alive():
        return ""
    near = str(arguments.get("topic") or arguments.get("query") or "").strip()
    try:
        forgotten = (await _call_server_async(
            "neuron", "forgotten",
            {"threshold": 5, "near": near, "top_n": 1})).strip()
    except Exception:  # noqa: BLE001
        return ""
    if not forgotten or forgotten.startswith("["):
        return ""
    _turns_since_stim = 0
    _stats["flashes"] += 1
    return f"\n\n🧠 (GM safety-net) {forgotten}"


def _inject_neuron_mode(arguments: dict) -> None:
    """Modalità operative dal blackboard: se il talamo ha scritto `cervello/mode`
    e `cervello/focus`, li inietta nelle chiamate a Neuron (get_context/pre_turn).
    L'agente può sempre sovrascriverli passandoli esplicitamente. Best-effort:
    blackboard assente o rotto → la chiamata passa senza modalità (= semantic)."""
    try:
        from gray_matter.state import state_get
        entry = state_get("cervello/mode")
        if entry and "mode" not in arguments:
            arguments["mode"] = entry["value"]
        focus = state_get("cervello/focus")
        if focus and "focus" not in arguments:
            arguments["focus"] = focus["value"]
    except Exception:  # noqa: BLE001
        pass


async def _bridge_blocks(topic: str, neurag_tags: set, limit: int) -> list[str]:
    """Cross-store bridges for this topic, one per block, strongest first.

    The limit is also the limit on REINFORCEMENT: showing a bridge is what
    counts as using it, so what does not fit is not reinforced. One bridge per
    block so the budget packs as many as fit instead of dropping them all. The
    rationale is TRUNCATED: the store keeps 500 chars because there it is
    documentation; here it is an injected hint, and five whole rationales alone
    blew the budget and took every bridge down with them.
    B4 — a bridge just promoted (5+ real uses) has proven its Neuron concept:
    confirm it (salience + trust). Best-effort."""
    from gray_matter.bridges import bridges_for
    rel = bridges_for(topic, tags=neurag_tags, limit=limit)
    out: list[str] = []
    for b in rel:
        why = (b.get("rationale") or "").strip()
        if len(why) > _BRIDGE_WHY_CHARS:
            why = why[:_BRIDGE_WHY_CHARS - 1].rstrip() + "…"
        out.append(f"🔗 {b['neuron']} ↔ {b['neurag']}" + (f" — {why}" if why else ""))
    promoted = [b["neuron"] for b in rel if b.pop("_just_promoted", False)]
    if promoted:
        try:
            await _call_server_async("neuron", "confirm",
                                     {"keywords": promoted, "confidence": 0.5})
        except Exception:  # noqa: BLE001
            pass
    return out


# --- Knowledge on pre_turn (2026-09-12) --------------------------------------
# The model calls pre_turn every turn and pulse never: on a real vault test the
# KB was indexed, bridged, and consulted zero times in the whole session. So the
# KB rides the call that actually happens. Gate first, content never: a SQL-only
# name/trigger lookup per keyword (knowledge_neighbors was built for this), and
# on a hit ONE pointer line — "the KB knows this, ask knowledge_query" — plus the
# bridges for the topic, all inside the proactive budget. No vector search here,
# ever: that stays behind an explicit knowledge_query / pulse, which is where the
# token cost belongs.
_KB_HINTS_PER_TURN = 1          # bridges shown next to the pointer; tokens, not a knob
_KB_HINT_CACHE: dict = {}       # keyword -> (line, tags, node); ("", set(), "") = known miss
_KB_HINT_SHOWN: set = set()     # pointers already shown this session: once per keyword.
                                # A repeat is ~25 tokens that invite a ~1000-token
                                # knowledge_query the model already chose to make or not.
_KB_HINT_CACHE_MAX = 500        # ponytail: clear-all when full; LRU if it ever matters


async def _kb_lookup(query: str) -> tuple:
    """Resolve one keyword to a KB node by trigger/name (SQL-only). Returns
    (pointer line, tags, node name); empty strings on a miss or any error."""
    miss = ("", set(), "")
    try:
        import json as _json
        raw = await _call_server_async("neurag", "knowledge_neighbors",
                                       {"query": query[:200], "depth": 1, "limit": 3})
        data = _json.loads(raw)
    except Exception:  # noqa: BLE001 — proactive = best-effort, never blocks pre_turn
        return miss
    node = data.get("node") or {}
    name = str(node.get("name") or "").strip()
    path = str(node.get("path") or "").strip()
    # A root node (one path segment) is the vault itself: its triggers are the
    # whole corpus' vocabulary, stopwords included, so a topic like "verifica
    # del puntatore" resolves to it through "del". That is not "the KB knows
    # this" — it is a miss.
    if not name or "/" not in path.strip("/"):
        return miss
    tags = {str(t) for t in (data.get("tags") or [])}
    near = [n["name"] for n in data.get("neighbors", []) if n.get("name")][:3]
    # The KB path repeats every ancestor and ends with the node name itself:
    # keep the parent segment only, and nothing when there is none.
    parent = path.rstrip("/").rsplit("/", 2)[-2:-1]
    where = parent[0] if parent and parent[0].lower() != name.lower() else ""
    line = (f'📚 KB knows "{name}"' + (f" (in {where})" if where else "")
            + (" · near: " + ", ".join(near) if near else "")
            + f' → knowledge_query("{name}") for the detail')
    return line, tags, name


# Un tool ricorda l'altro: `around`/`brainstorm` sono letture che nessun loop
# chiama da solo, quindi il momento giusto glielo dice pre_turn. La parola
# arriva dal modello stesso (topic/keywords), non dal testo dell'utente.
# ponytail: lista di parole, non un classificatore — un embedding se i buchi si accumulano.
_PROBLEM_WORDS = frozenset({
    "bug", "debug", "fix", "error", "errore", "issue", "crash", "fail", "failure",
    "fallisce", "fallito", "dilemma", "decision", "decisione", "problem", "problema",
    "why", "perche", "perché", "regression", "regressione", "broken", "rotto"})


def _brainstorm_hint(arguments: dict) -> str:
    """One line on a pre_turn whose topic/keywords name a problem: point the
    model at gray_matter_brainstorm. Empty otherwise — the common case."""
    if not BRAINSTORM_HINT:
        return ""
    text = " ".join([str(arguments.get("topic", "")),
                     *map(str, arguments.get("keywords") or [])]).lower()
    words = set(re.findall(r"[a-zà-ù]+", text))
    if not (words & _PROBLEM_WORDS):
        return ""
    return ("\n💡 Looks like a problem or a decision: gray_matter_brainstorm(seed) "
            "before answering — the seed is the problem in one sentence.")


async def _knowledge_hint(arguments: dict) -> str:
    """The KB addendum for a pre_turn: one pointer on the first keyword the KB
    resolves, plus the topic's bridges. Empty when NeuRAG is off, isolated, the
    budget is zero, or nothing matches — which is the common case and costs a
    few SQL lookups, cached per keyword for the session."""
    neurag = _registry.get_server("neurag")
    if not (neurag and neurag.is_alive() and neurag.collaborative) or PROACTIVE_BUDGET <= 0:
        return ""
    topic = " ".join(str(arguments.get("topic", "")).split())[:200]
    kws = [str(k).strip() for k in (arguments.get("keywords") or []) if str(k).strip()]
    blocks: list[str] = []
    tags: set = set()
    for q in [*kws[:5], topic]:
        if not q:
            continue
        key = q.lower()
        fresh = key not in _KB_HINT_CACHE
        if fresh:
            if len(_KB_HINT_CACHE) >= _KB_HINT_CACHE_MAX:
                _KB_HINT_CACHE.clear()
            _KB_HINT_CACHE[key] = await _kb_lookup(q)
        line, kb_tags, node = _KB_HINT_CACHE[key]
        if not line or key in _KB_HINT_SHOWN:
            continue
        _KB_HINT_SHOWN.add(key)
        tags = kb_tags                  # the node's tags feed the bridges only with its pointer
        blocks.append(line)
        _stats["kb_hints"] += 1
        # A keyword the KB resolves by name IS a bridge: Neuron concept on one
        # side, KB node on the other. Minted on first sighting in the session
        # (add_bridge is idempotent and reinforces on repeat — a cached hit
        # would otherwise promote a bridge every turn the keyword recurs).
        if fresh and q in kws:
            from gray_matter.bridges import add_bridge
            if add_bridge(q, node, f"co-named on pre_turn '{topic}'"):
                _stats["bridges_added"] += 1
        break                       # one pointer is enough; the rest is a query away
    blocks.extend(await _bridge_blocks(topic, tags, _KB_HINTS_PER_TURN))
    extra, _dropped = _fit(PROACTIVE_BUDGET, blocks)
    return ("\n\n" + extra) if extra else ""


async def _tool_brainstorm(args: dict) -> list[TextContent]:
    """Brain (GM, thalamus): what surrounds a problem, with its history.

    Neuron `around` gives the mid-band nodes — related but not obvious — each
    with its facts ("chose X because Y") and the reasons on its links: a past
    decision, a bug already solved once. NeuRAG gives the nearest chunks: a
    practice, a spec. Nothing is scored here: both sides carry their own
    measure, and this tool no longer invents one. The previous version took
    the TAIL of an ordinary search and labelled rank as distance — the 8th
    nearest chunk of 6000 called "distance 1.0" (seen live 2026-09-14).
    For dilemmas and decisions; a dormant node is marked so the caller can
    confirm() it (or recall() it if archived)."""
    seed = str(args.get("seed", "")).strip()
    n = min(max(int(args.get("n", 5) or 5), 1), 10)
    if not seed:
        return [TextContent(type="text", text=(
            "gray_matter_brainstorm: serve un 'seed' non vuoto — il problema, il "
            "dilemma o la decisione. Torna il vicinato non ovvio in memoria (con i "
            "fatti e le ragioni) e i documenti piu' vicini."))]
    parts = [f"Spunti attorno a '{seed}'"]
    try:
        parts.append(await _call_server_async("neuron", "around", {"topic": seed, "n": n}))
    except Exception as exc:  # noqa: BLE001 — neuron assente: resta la conoscenza
        parts.append(f"memoria: non disponibile ({exc})")
    try:
        parts.append(await _call_server_async("neurag", "knowledge_query",
                                              {"query": seed, "top_n": min(n, 3)}))
    except Exception as exc:  # noqa: BLE001 — neurag assente: resta la memoria
        parts.append(f"conoscenza: non disponibile ({exc})")
    parts.append("Dormant → confirm(keywords) per rialzarlo; archiviato → recall(keyword).")
    return [TextContent(type="text", text="\n\n".join(parts))]


_is_sleeping: bool = False

# version= explicitly: without it the SDK reports ITS OWN version in the
# handshake, so a client asking which Gray Matter it is talking to was told
# "1.28.1" — the MCP library's number. Both peers already pass it.
app = Server("gray-matter", version=__version__)

# MCP handshake instructions (INSTALLER-UX §8b): the loop-guidance for clients
# that honor `instructions` (Cursor/VS Code/Codex) — no hook needed there. The
# per-client hooks stay for clients that ignore this field. Keep in sync with
# Neuron/clients/claude-code-hook (same loop, GM-gateway flavored).
GM_INSTRUCTIONS = (
    "Gray-Matter gateway: Neuron (persistent semantic memory) + NeuRAG (knowledge "
    "base) behind one proxy — their tools are served here pass-through.\n"
    "Each substantive turn: call pre_turn(topic, keywords) BEFORE replying (fold "
    "the returned context in silently), then store_turn(topic, keywords, links) "
    "AFTER, to persist what is new. gray_matter_pulse(topic) merges memory + "
    "knowledge + flash in one call.\n"
    "Keywords = 3-5 concept NOUNS (no verbs/paths); links typed, never a "
    "self-link; before minting a concept check find_candidates; never store "
    "secrets or tokens. Skip on procedural turns (ack/thanks/yes-no)."
)


  # server_name -> consecutive failures


_subservers_ready = False


async def _ensure_subservers() -> None:
    """Register Neuron/NeuRAG once per process, however `app` is served.

    Only the stdio main() ran `_bootstrap_subservers`. The HTTP bridges import
    `app` and serve it directly, so a remote client saw GM's own 7 tools and
    none of Neuron's or NeuRAG's — a bridge that "worked" with most of the
    suite missing, measured 2026-10-24. Once, like main(): a sub-server that
    fails here is retried by the same paths that retry it under stdio."""
    global _subservers_ready
    if not _subservers_ready:
        _subservers_ready = True
        await _bootstrap_subservers()


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Dynamically list tools from all registered servers."""
    await _ensure_subservers()
    tools = []

    # Gray-Matter's own tools
    tools.append(Tool(
        name="gray_matter_pulse",
        description="Pre-context + knowledge chunks + flash. Calls neuron_get_context and neurag_query in parallel, merges the results, uses the cache.",
        inputSchema={
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Topic to search for"},
                "top_n": {
                    "type": "integer", "description": "Number of chunks (default 5)",
                    "default": 5, "minimum": 1, "maximum": 10,
                },
            },
            "required": ["topic"],
        },
    ))
    tools.append(Tool(
        name="gray_matter_status",
        description="Show Gray-Matter status: registered servers, cache, counters.",
        inputSchema={"type": "object", "properties": {}},
    ))
    tools.append(Tool(
        name="gray_matter_bridge",
        description="Persist a cross-store bridge: a link between a Neuron concept and a NeuRAG knowledge node the orchestrator found to relate. Recalled in future pulses on either endpoint.",
        inputSchema={
            "type": "object",
            "properties": {
                "neuron_concept": {"type": "string", "description": "Neuron concept/keyword"},
                "neurag_node": {"type": "string", "description": "NeuRAG node/topic"},
                "rationale": {"type": "string", "description": "Why they connect"},
            },
            "required": ["neuron_concept", "neurag_node"],
        },
    ))
    tools.append(Tool(
        name="gray_matter_state_set",
        description="Blackboard (GM, thalamus): publish key=value with an optional TTL in seconds. Keys are 'org/component/name'. Returns the entry with its version.",
        inputSchema={
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Key, e.g. 'cervello/mode'"},
                "value": {"description": "Arbitrary JSON value"},
                "ttl": {"type": "number", "description": "Expiry in seconds (default: never)"},
            },
            "required": ["key", "value"],
        },
    ))
    tools.append(Tool(
        name="gray_matter_state_get",
        description="Blackboard: read key. None if missing or expired — state decays on its own.",
        inputSchema={
            "type": "object",
            "properties": {"key": {"type": "string"}},
            "required": ["key"],
        },
    ))
    tools.append(Tool(
        name="gray_matter_state_delta",
        description="Blackboard: changes from version `since` onwards, filtered by key prefix (expired entries included).",
        inputSchema={
            "type": "object",
            "properties": {
                "prefix": {"type": "string", "description": "Key prefix (default '')"},
                "since_version": {"type": "integer", "description": "Version to list changes from (default 0)"},
            },
        },
    ))
    tools.append(Tool(
        name="gray_matter_brainstorm",
        description="Brain (GM, thalamus): what surrounds a problem, with its history. Mid-band memory nodes (related but not obvious) with their facts and link rationales — a past decision, a bug solved once — plus the nearest knowledge chunks. For dilemmas, problems and decisions. Requires 'seed'.",
        inputSchema={
            "type": "object",
            "properties": {
                "seed": {"type": "string", "description": "The problem, dilemma or decision to think around"},
                "n": {"type": "integer", "description": "Memory nodes to show (default 5, max 10); knowledge chunks capped at 3"},
            },
            "required": ["seed"],
        },
    ))

    # Tools from registered servers (F12: re-publish REAL schemas, fetched once
    # from each worker and cached; fall back to an empty schema if unavailable so
    # list_tools never blocks on a cold/broken worker).
    for server in _registry.alive_servers():
        await _ensure_schemas(server)
        for tool_name in server.tool_names:
            meta = server.tool_schemas.get(tool_name) or {}
            tools.append(Tool(
                name=tool_name,
                description=meta.get("description") or f"({server.name}) {tool_name}",
                inputSchema=meta.get("inputSchema") or {"type": "object", "properties": {}},
            ))

    return tools


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    global _last_call_time, _flash_counter

    await _ensure_subservers()
    _last_call_time = time.time()
    _flash_counter += 1
    _tool_calls[name] = _tool_calls.get(name, 0) + 1

    # --- Gray-Matter orchestrated tools ---

    if name == "gray_matter_pulse":
        global _is_sleeping
        _is_sleeping = False
        # Validate the topic (mirror of the bridge ingest guard): coerce, strip,
        # collapse whitespace, cap. Empty/whitespace-only -> nothing to search.
        topic = " ".join(str(arguments.get("topic", "")).split())[:200]
        if not topic:
            return [TextContent(type="text", text="pulse: empty topic.")]
        top_n = min(max(int(arguments.get("top_n", KNOWLEDGE_TOP_N)), 1), 10)
        _t0 = time.monotonic()
        _stats["pulses"] += 1
        _remember_topic(topic)   # D4: conversation buffer (anche sui cache hit)

        # Cache hit? (one shared cache — see _ctx_cache)
        cached = _ctx_cache.get(topic)
        if cached is not None:
            _stats["cache_hits"] += 1
            return [TextContent(type="text", text=cached)]
        _stats["cache_misses"] += 1

        # Collect calls to registered servers (track which is which for v3b).
        tasks, labels = [], []

        neuron = _registry.get_server("neuron")
        if neuron and neuron.is_alive() and neuron.collaborative:
            # max_tokens esplicito: `get_context` ha il suo budget in caratteri
            # ma il default (400) lo decideva Neuron, non l'utente.
            n_args = {"topic": topic, "depth": 1,
                      "max_tokens": MEMORY_MAX_TOKENS}
            _inject_neuron_mode(n_args)   # modalità dal blackboard
            tasks.append(_call_server_async("neuron", "get_context", n_args))
            labels.append("neuron")

        neurag = _registry.get_server("neurag")
        if neurag and neurag.is_alive() and neurag.collaborative:
            # D4 — multi-turn RAG: espandi la query NeuRAG con i topic recenti
            # (Neuron ha già la sua context window; la cache resta keyed sul
            # topic puro, quindi l'espansione non inquina i cache hit).
            recent = [t for t in _topic_buffer if t != topic]
            rag_query = topic + (" " + " ".join(recent) if recent else "")
            tasks.append(_call_server_async("neurag", "knowledge_query", {"query": rag_query[:300], "top_n": top_n})); labels.append("neurag")

        if not tasks:
            return [TextContent(type="text", text="No servers available for pulse.")]

        # Parallel execution
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Auto-build cross-links once: if NeuRAG has nodes but zero links,
        # rebuild so future queries get link enrichment. One-shot per session.
        global _neurag_links_built
        if not _neurag_links_built and "neurag" in labels:
            try:
                status_raw = await _call_server_async("neurag", "knowledge_status", {})
                import json as _json
                ns = _json.loads(status_raw) if isinstance(status_raw, str) else status_raw
                if ns.get("links", 0) == 0 and ns.get("nodes", 0) > 1:
                    await _call_server_async("neurag", "knowledge_rebuild_links", {})
            except Exception:  # noqa: BLE001
                pass
            _neurag_links_built = True

        context_parts = []
        neurag_hit = False
        for lbl, r in zip(labels, results):
            if isinstance(r, Exception):
                context_parts.append(f"[error: {r}]")
            elif r:
                context_parts.append(r)
                if lbl == "neurag" and "No results" not in str(r):
                    neurag_hit = True

        response = "\n---\n".join(context_parts) if context_parts else "No results."

        # D3 — knowledge proattiva: vicini strutturati del nodo NeuRAG matchato
        # (parent/children/links, depth 2) non già presenti nella risposta.
        # JSON dal tool knowledge_neighbors: niente parsing di prosa (anti-F15).
        # Va PRIMA dei bridge: la stessa risposta porta i tag canonici del nodo,
        # ed è su quelli che i bridge fanno il join (§4). Un secondo round-trip
        # solo per chiedere quattro parole non lo vogliamo nella pulse.
        # Tutto ciò che segue è PROATTIVO: non l'ha chiesto nessuno, quindi vive
        # dentro `proactive_budget_chars`. A 0 la pulse resta solo le risposte
        # vere — che è una risposta legittima per chi ha il contesto stretto.
        proactive: list[str] = []
        neurag_tags: set[str] = set()
        if neurag_hit and PROACTIVE_BUDGET > 0:
            try:
                import json as _json
                raw = await _call_server_async(
                    "neurag", "knowledge_neighbors",
                    {"query": topic, "depth": 2, "limit": 5})
                data = _json.loads(raw)
                neurag_tags = {str(t) for t in (data.get("tags") or [])}
                fresh = [n["name"] for n in data.get("neighbors", [])
                         if n.get("name") and n["name"].lower() not in response.lower()][:3]
                if fresh:
                    proactive.append("💡 Potrebbe interessarti: " + ", ".join(fresh))
            except Exception:  # noqa: BLE001 — proattiva = best-effort, mai bloccare la pulse
                pass

        # Cross-store bridges the orchestrator has persisted for this topic.
        # Matched on whole tokens AND on the tag identity above — a bridge to a
        # node whose NAME says nothing about the topic is reachable through its
        # tags, which is the whole point of the substrate.
        if PROACTIVE_BUDGET > 0:
            proactive.extend(await _bridge_blocks(topic, neurag_tags, _BRIDGES_PER_PULSE))

        # Flash: serendipitous dormant-concept recall, fired at a topic shift.
        if PROACTIVE_BUDGET > 0:
            flash_note, concept = await _maybe_flash(topic)
            if flash_note:
                proactive.append(flash_note)
                # v3b auto-discovery: a mid-band dormant Neuron concept surfaced on a
                # topic where NeuRAG has real knowledge → that co-occurrence is a bridge
                # worth keeping. Persist it (idempotent, gated by the flash rate-limit).
                if concept and neurag_hit:
                    from gray_matter.bridges import add_bridge
                    if add_bridge(concept, topic, f"co-surfaced on '{topic}'"):
                        _stats["bridges_added"] += 1

        # Il flash è primo: è l'unico contenuto proattivo che non si può
        # ri-ottenere chiedendo (i bridge stanno in `gray-matter bridges`, i
        # vicini in `knowledge_neighbors`). Un flash tagliato è perso.
        extra, dropped = _fit(PROACTIVE_BUDGET, list(reversed(proactive)))
        if extra:
            response += "\n\n" + extra
        if dropped:
            response += (f"\n\n(+{dropped} spunti omessi: budget proattivo "
                         f"{PROACTIVE_BUDGET} char — `gray-matter config set "
                         f"proactive_budget_chars <n>`)")

        # Cache + record the real-work latency (this was a miss).
        _stim_seen(response)          # un pulse con stimoli ricarica il safety-net
        _ctx_cache.set(topic, response)
        _stats["pulse_ms_total"] += (time.monotonic() - _t0) * 1000

        return [TextContent(type="text", text=response)]

    if name == "gray_matter_status":
        lines = [
            f"Gray-Matter v{__version__}",
            f"Flash counter: {_flash_counter}",
            f"Servers: {len(_registry.all_servers())}",
            _registry.summary(),
        ]
        return [TextContent(type="text", text="\n".join(lines))]

    if name == "gray_matter_bridge":
        from gray_matter.bridges import add_bridge
        created = add_bridge(arguments["neuron_concept"], arguments["neurag_node"],
                             arguments.get("rationale", ""))
        return [TextContent(type="text", text="Bridge saved." if created else "Bridge already exists.")]

    if name == "gray_matter_state_set":
        from gray_matter.state import state_set
        entry = state_set(arguments["key"], arguments.get("value"),
                          arguments.get("ttl"))
        return [TextContent(type="text", text=json.dumps(entry))]

    if name == "gray_matter_state_get":
        from gray_matter.state import state_get
        entry = state_get(arguments["key"])
        return [TextContent(type="text", text=json.dumps(entry) if entry
                            else "state: None (absent or expired)")]

    if name == "gray_matter_state_delta":
        from gray_matter.state import state_delta
        delta = state_delta(arguments.get("prefix", ""),
                            int(arguments.get("since_version", 0)))
        return [TextContent(type="text", text=json.dumps(delta))]

    if name == "gray_matter_brainstorm":
        return await _tool_brainstorm(arguments)

    # A write to episodic memory can make a cached pulse stale: drop the entries
    # for the just-written topic so the next pulse rebuilds fresh (targeted, not a
    # full flush — other topics keep their cache).
    if name == "store_turn":
        _ctx_cache.invalidate_related(str(arguments.get("topic", "")))

    # --- Route to registered server (pass-through) ---
    # Unannounced tools (the tool diet hides upkeep/admin ones from list_tools)
    # still route by name: the worker dispatches by name and answers itself
    # when a tool really does not exist.
    server = (_registry.find_server_by_tool(name)
              or _registry.get_server("neurag" if name.startswith("knowledge_") else "neuron"))
    if server is None:
        return [TextContent(type="text", text=f"Tool '{name}' not found in any registered server.")]

    # Modalità dal blackboard: il talamo decide, Neuron esegue (parametro).
    if server.name == "neuron" and name in ("get_context", "pre_turn"):
        _inject_neuron_mode(arguments)

    result = await _call_server_async(server.name, name, arguments)
    # La KB viaggia sulla call che il modello fa davvero (vedi _knowledge_hint).
    is_pre = server.name == "neuron" and name == "pre_turn"
    kb = (await _knowledge_hint(arguments) if is_pre else "")
    bs = _brainstorm_hint(arguments) if is_pre else ""
    # Rete di sicurezza stimoli: se il piggyback di Neuron non passa da troppi
    # turni (LLM ha "dimenticato" i tool giusti), GM lo rilancia qui.
    note = await _safety_net_note(name, arguments, result or "")
    return [TextContent(type="text", text=(result or "(empty)") + kb + bs + note)]


# Persistent workers: one long-lived subprocess per server (imported once, model
# kept warm) instead of a cold-import subprocess per call. See gray_matter/_worker.py.
_workers: dict = {}          # server_name -> Popen
_worker_locks: dict = {}     # server_name -> asyncio.Lock (serialize the shared pipe)
_worker_lat: dict = {}       # server_name -> {calls, ms_total, last_ms} (tempo NEL tool)
_prewarmed: set = set()      # servers already warmed (D2), so we warm each once
_neurag_links_built: bool = False  # auto-build links once when links=0 and nodes>1

# Cheap read fired to warm a worker: spawns the subprocess (pays the import) and
# loads the model (Neuron's fastembed) BEFORE the first real pulse, so that pulse
# isn't the one paying the ~cold-start tax. Unknown servers get import-warm only.
_WARM_TOOL = {
    "neuron": ("status", {}),
    "neurag": ("knowledge_query", {"query": "warmup", "top_n": 1}),
}


async def _prewarm_workers():
    """D2: pre-warm persistent workers so the FIRST pulse is fast, not cold.

    Waits for servers to register (the registry starts empty), then spawns each
    collaborative server's worker and fires one cheap read to load its model.
    Best-effort: on any failure the server is left un-warmed and the lazy path in
    `_worker_for` still handles it on demand. Disable with GM_PREWARM=0."""
    if os.environ.get("GM_PREWARM", "1" if _cfg["prewarm"] else "0") == "0":
        return
    # Warming is the daemon's job when there is one: a gateway that pre-warms
    # spawns exactly the local worker set the shared model exists to avoid, and
    # it would do it eagerly at startup, before any tool call could delegate.
    if _daemon_reachable():
        return
    while True:
        # Re-probe EVERY sweep, and bypass the backoff in _daemon_reachable():
        # that backoff exists so a missing daemon isn't probed per tool call,
        # but here it is the bug. Two clients starting in the same second both
        # find no daemon, both set the 30 s backoff; the one that loses the
        # election then pre-warms a full local set inside its own blind window
        # — and those workers hold the graph files for the rest of the process.
        # Measured: two Claude Desktop surfaces 1 s apart, two worker sets, one
        # of them permanently degraded to sqlite3. A 0.4 s probe every 2 s at
        # startup is cheaper than a duplicate 1.1 GB model and a second writer.
        if not _IS_DAEMON and gm_answers(GRAY_MATTER_HOST, resolve_port()):
            _shutdown_workers()          # dismiss anything this sweep spawned
            _prewarmed.clear()
            return
        for s in _registry.alive_servers():
            if s.name in _prewarmed or not s.collaborative:
                continue
            _prewarmed.add(s.name)                     # mark first: don't hammer on repeated failure
            tool, args = _WARM_TOOL.get(s.name, (None, None))
            try:
                if tool is None:
                    _worker_for(s.name)                # unknown server: at least pay the import now
                else:
                    await _call_server_async(s.name, tool, args)
            except Exception:  # noqa: BLE001
                _prewarmed.discard(s.name)             # let a later sweep (or lazy path) retry
        await asyncio.sleep(2)


def _worker_for(server_name: str):
    pkg = {"neurag": "neurag.server", "neuron": "neuron.server"}.get(server_name, server_name + ".server")
    p = _workers.get(server_name)
    if p is None or p.poll() is not None:        # not started, or died -> (re)spawn
        # Windows: suppress the console window for the worker (a piped child would
        # otherwise pop a visible CMD). GM's daemon already does this; the worker
        # didn't — harmless before, but the startup self-bootstrap now spawns it
        # eagerly, so the window showed at launch.
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        p = subprocess.Popen(
            [sys.executable, "-m", "gray_matter._worker", pkg],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1,
            creationflags=creationflags,
        )
        _workers[server_name] = p
    return p


def _reap_worker(p: "subprocess.Popen") -> None:
    """kill() alone is not enough: without wait() the child lingers as a
    zombie (POSIX) / leaked handles, and its PIPE buffers stay open."""
    try:
        p.kill()
    except Exception:  # noqa: BLE001
        pass
    try:
        p.wait(timeout=3)
    except Exception:  # noqa: BLE001
        pass
    for fh in (getattr(p, "stdin", None), getattr(p, "stdout", None),
               getattr(p, "stderr", None)):
        try:
            if fh is not None:
                fh.close()
        except Exception:  # noqa: BLE001
            pass


def _shutdown_workers() -> None:
    """Flush sincrono dei worker prima di morire (checkpoint finale).

    Su Windows non esistono segnali: Popen.terminate() è TerminateProcess, che
    uccide senza dare al worker la possibilità di salvare. Il worker risponde a
    {"op": "shutdown"} facendo save_all() e uscendo; solo se non esce nel
    timeout lo si termina a forza (l'ultimo checkpoint periodico copre il resto).
    """
    for name, p in list(_workers.items()):
        try:
            p.stdin.write(json.dumps({"op": "shutdown"}) + "\n")
            p.stdin.flush()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.terminate()
                try:
                    p.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    p.kill()
        except (BrokenPipeError, OSError):
            pass
        _workers.pop(name, None)


def _reap_orphans() -> None:
    """Single-instance: termina i processi della suite rimasti orfani.

    Quando il client muore, il gateway e i suoi worker restano vivi (process
    group staccato) e scrivono sullo stesso DB. All'avvio di un'istanza nuova
    si chiudono subito, l'ultima istanza vince. Nota: il python.exe del venv
    e' il redirector CPython — Popen vede lo stub, il vero interprete e' suo
    figlio. Uccidere lo stub non uccide il figlio: si itera finche' il
    registro pids non e' pulito (la morte si propaga per un paio di giri).
    """
    try:
        from gray_matter import pids as _pids
        for _ in range(3):
            orph = _pids.orphans()
            if not orph:
                return
            for o in orph:
                try:
                    if _pids.alive(o["pid"]):
                        subprocess.run(
                            ["taskkill", "/PID", str(o["pid"]), "/F"],
                            capture_output=True, timeout=10,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        )
                    _pids.forget(o["pid"])
                except Exception:  # noqa: BLE001 — best-effort, mai bloccare
                    pass
            time.sleep(0.3)
    except Exception:  # noqa: BLE001
        pass


# --- Shared worker set ------------------------------------------------------
# The workers hold the embedding models (~1.1 GB for the pair) AND the write
# handle on the graph store. One set PER GATEWAY meant every open AI client paid
# the gigabyte again and, worse, put another writer on the same DB — the clobber
# risk pids.orphans() already warns about. So: the daemon owns the workers, and
# a stdio gateway asks it over IPC. If no daemon answers, the gateway spawns its
# own set exactly as before — the fallback is the old code path, untouched.
_IS_DAEMON = False
_daemon_gone_until = 0.0        # backoff so a missing daemon isn't probed per call


def _daemon_reachable() -> bool:
    global _daemon_gone_until
    if _IS_DAEMON or os.environ.get("GM_SHARED_WORKERS", "1") == "0":
        return False
    if time.time() < _daemon_gone_until:
        return False
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        return True
    _daemon_gone_until = time.time() + 30
    return False


async def _via_daemon(payload: dict, timeout: float = 60.0):
    """Send one IPC request to the daemon; None means 'no daemon, do it yourself'.

    Blocking socket work goes to the executor: this runs inside the stdio
    server's event loop and a 60 s tool call would otherwise freeze the client.
    """
    if not _daemon_reachable():
        return None
    global _daemon_gone_until
    loop = asyncio.get_running_loop()
    try:
        resp = await loop.run_in_executor(None, lambda: _send_ipc(payload, timeout))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(resp, dict) or "error" in resp:
        # A refused connection means the daemon died mid-flight -> fall back and
        # stop probing for a bit. An "unauthorized" is NOT transient: still fall
        # back, but it is worth seeing in the log rather than silently degrading.
        err = (resp or {}).get("error", "")
        if err == "unauthorized":
            print("gray-matter: IPC token rejected — running workers locally",
                  file=sys.stderr)
        _daemon_gone_until = time.time() + 30
        return None
    return resp.get("result")


async def _call_server_async(server_name: str, tool_name: str, arguments: dict) -> str:
    """Call a server tool via its persistent worker (imported once, model kept warm).

    Prefers the daemon's shared worker; spawns a local one only if there is none.
    """
    shared = await _via_daemon({"action": "call", "server": server_name,
                                "tool": tool_name, "args": arguments},
                               timeout=IPC_TOOL_TIMEOUT)
    if shared is not None:
        return shared
    lock = _worker_locks.setdefault(server_name, asyncio.Lock())
    async with lock:                              # one request at a time per pipe
        p = _worker_for(server_name)
        # get_running_loop, not get_event_loop: all three call sites are inside
        # coroutines, and get_event_loop() is deprecated when a loop is already
        # running (3.12+) — on 3.14 the no-loop case raises outright.
        loop = asyncio.get_running_loop()

        def _io() -> str:
            p.stdin.write(json.dumps({"tool": tool_name, "args": arguments}) + "\n")
            p.stdin.flush()
            return p.stdout.readline()

        try:
            # First Neuron call loads fastembed -> allow headroom.
            resp_line = await asyncio.wait_for(loop.run_in_executor(None, _io), timeout=60)
        except Exception as e:  # noqa: BLE001 — timeout or pipe error: drop the worker
            _reap_worker(p)
            _workers.pop(server_name, None)
            _registry.mark_dead(server_name)
            return f"[{server_name}] error: {e}"

    if not resp_line:
        _registry.mark_dead(server_name)
        return f"[{server_name}] error: worker gave no response"
    try:
        resp = json.loads(resp_line)
    except Exception:
        return f"[{server_name}] error: bad worker response"
    if not resp.get("ok"):
        # ponytail: trace nel messaggio — L2 è intermittente, quando ricapita
        # vogliamo il traceback intero, non solo str(e)
        tail = f"\n{resp['trace']}" if resp.get("trace") else ""
        return f"[{server_name}] error: {resp.get('error')}{tail}"
    # Cronometro per server: il worker misura l'esecuzione del tool (modello
    # già caldo, senza pipe/proxy) — è il numero che dice DOVE va il tempo.
    if resp.get("ms") is not None:
        lat = _worker_lat.setdefault(server_name, {"calls": 0, "ms_total": 0.0, "last_ms": 0.0})
        lat["calls"] += 1
        lat["ms_total"] += float(resp["ms"])
        lat["last_ms"] = float(resp["ms"])
    return resp["text"]


async def _fetch_tool_schemas(server_name: str) -> dict:
    """F12: ask a server's worker for its real tool list (name -> {description,
    inputSchema}) so GM can re-publish accurate pass-through schemas. Best-effort:
    returns {} on any failure (caller falls back to an empty schema)."""
    shared = await _via_daemon({"action": "schemas", "server": server_name},
                               timeout=IPC_TOOL_TIMEOUT)
    if shared is not None:
        return shared
    lock = _worker_locks.setdefault(server_name, asyncio.Lock())
    async with lock:
        p = _worker_for(server_name)
        loop = asyncio.get_running_loop()

        def _io() -> str:
            p.stdin.write(json.dumps({"op": "list_tools"}) + "\n")
            p.stdin.flush()
            return p.stdout.readline()

        try:
            resp_line = await asyncio.wait_for(loop.run_in_executor(None, _io), timeout=60)
        except Exception:  # noqa: BLE001 — pipe/timeout: leave schemas unknown
            return {}
    try:
        resp = json.loads(resp_line)
    except Exception:  # noqa: BLE001
        return {}
    if not resp.get("ok"):
        return {}
    return {
        t["name"]: {"description": t.get("description") or "",
                    "inputSchema": t.get("inputSchema") or {"type": "object", "properties": {}}}
        for t in resp.get("tools", []) if t.get("name")
    }


async def _ensure_schemas(server) -> None:
    """Populate a server's real tool schemas once (cached on the ServerEntry)."""
    if server.tool_schemas:
        return
    schemas = await _fetch_tool_schemas(server.name)
    if schemas:
        server.tool_schemas = schemas


_SUBSERVER_MODULES = {"neuron": "neuron.server", "neurag": "neurag.server"}


def detect_subservers() -> list[str]:
    """Installed sub-servers importable right now (gateway self-discovery).

    Un tool andato standalone (`<tool> go-standalone` / `gray-matter deregister
    --tool ...`) è escluso anche se importabile: ha la sua entry MCP diretta nei
    client — ri-gestirlo qui duplicherebbe i suoi tool."""
    import importlib.util
    try:
        from gray_matter.clients import unmanaged_tools
        skip = unmanaged_tools()
    except Exception:  # noqa: BLE001 — mai bloccare il bootstrap
        skip = set()
    out = []
    for name, mod in _SUBSERVER_MODULES.items():
        if name in skip:
            continue
        try:
            if importlib.util.find_spec(mod) is not None:
                out.append(name)
        except Exception:  # noqa: BLE001 — broken/partial install
            pass
    return out


async def _bootstrap_subservers() -> None:
    """Gateway model: the client launches only GM, so the sub-servers no longer
    auto-register via IPC. GM self-discovers the installed ones, fetches their real
    tools from the worker (F12) and registers them as MANAGED so `list_tools`
    re-publishes them. Best-effort; a sub-server that fails to answer is skipped
    (a later autoregister or a retry can still add it)."""
    for name in detect_subservers():
        if _registry.get_server(name):
            continue
        schemas = await _fetch_tool_schemas(name)
        if schemas:
            _registry.register_managed(name, list(schemas), schemas)


async def _sleep_monitor():
    """Background: if idle > IDLE_SLEEP_TIMEOUT, flag sleep.

    Sleep means servers are marked 'sleeping'. First client call wakes them.
    """
    global _is_sleeping
    while True:
        await asyncio.sleep(30)
        # Daily backup of the three stores (backup.py): a no-op once today's
        # folder exists, so this costs one exists() per tick. Daemon only —
        # every stdio gateway runs this monitor too, and four processes racing
        # for the same .tmp folder at midnight is not a backup. Off the loop
        # thread: a copy of a few MB must not stall the IPC listener.
        if _IS_DAEMON:
            try:
                from gray_matter import backup as _backup
                folder, errors = await asyncio.to_thread(_backup.run)
                for e in errors:
                    print(f"[gray-matter] backup: {e}", file=sys.stderr)
                if folder:
                    print(f"[gray-matter] backup: {folder}", file=sys.stderr)
            except Exception as exc:  # noqa: BLE001 — say it, never crash the monitor
                print(f"[gray-matter] backup skipped: {exc}", file=sys.stderr)
        now = time.time()
        idle = now - _last_call_time

        if idle > IDLE_SLEEP_TIMEOUT and not _is_sleeping:
            _is_sleeping = True
            for s in _registry.all_servers():
                s.status = "sleeping"
            # Idle maintenance: let unused bridges (unconfirmed hypotheses) decay.
            # Daemon only, like the backup above: every stdio gateway runs this
            # monitor with its OWN idle clock, so the decay ran once per open
            # client and its speed depended on how many were open (ADR-010 F0).
            # The daemon sees every gateway's calls: its idle is the real one.
            if _IS_DAEMON:
                try:
                    from gray_matter.bridges import decay
                    decay()
                except Exception:  # noqa: BLE001
                    pass
        elif idle < IDLE_SLEEP_TIMEOUT and _is_sleeping:
            _is_sleeping = False


async def _reap_dead_workers():
    """A server marked dead means its CLIENT stopped heart-beating. We must NOT
    kill that pid — in the additive model it's the client's own process, not
    ours (the old code SIGTERM'd it, a real bug). What Gray-Matter actually owns
    is the persistent worker subprocess; drop it so the next call to that server
    respawns a fresh worker via `_worker_for`."""
    while True:
        await asyncio.sleep(HEARTBEAT_INTERVAL * 2)
        for server in _registry.all_servers():
            if server.status != "dead":
                continue
            p = _workers.pop(server.name, None)
            if p is not None:
                _reap_worker(p)


def _build_stats() -> dict:
    """Live observability counters — the orchestrator's tachometer."""
    from gray_matter.bridges import all_bridges
    hits, misses = _stats["cache_hits"], _stats["cache_misses"]
    total = hits + misses
    return {
        "pulses": int(_stats["pulses"]),
        "cache_hits": int(hits),
        "cache_misses": int(misses),
        "cache_hit_rate": round(hits / total, 3) if total else 0.0,
        "cache_size": _ctx_cache.size(),
        "flashes": int(_stats["flashes"]),
        "bridges_added_session": int(_stats["bridges_added"]),
        "bridges_total": len(all_bridges()),
        # no kb_hints here: pointers are minted in each stdio gateway, not in
        # the daemon — the knowledge_neighbors count below is the gate's lookups
        "tool_calls": dict(sorted(_tool_calls.items(), key=lambda kv: -kv[1])),
        "avg_miss_ms": round(_stats["pulse_ms_total"] / misses, 1) if misses else 0.0,
        "workers_alive": [n for n, p in _workers.items() if p.poll() is None],
        "worker_latency": {n: {"calls": v["calls"],
                               "avg_ms": round(v["ms_total"] / v["calls"], 1) if v["calls"] else 0.0,
                               "last_ms": v["last_ms"]}
                           for n, v in _worker_lat.items()},
    }


async def _build_doctor() -> dict:
    """Health snapshot: servers, workers, cache, bridges (+ vector tier NeuRAG)."""
    from gray_matter.bridges import all_bridges
    servers = [{
        "name": s.name, "status": s.status, "alive": s.is_alive(),
        "collaborative": s.collaborative,
        "worker": s.name in _workers and _workers[s.name].poll() is None,
    } for s in _registry.all_servers()]
    out = {
        "version": __version__,
        "sleeping": _is_sleeping,
        "servers": servers,
        "cache_size": _ctx_cache.size(),
        "bridges_total": len(all_bridges()),
    }
    # Degradato mai silenzioso (nota Claudio 2026-07-20): se NeuRAG gira sul
    # tier sqlite3 (niente pyturso → coseno in Python), il doctor deve dirlo.
    neurag = _registry.get_server("neurag")
    if neurag and neurag.is_alive():
        try:
            import json as _json
            raw = await _call_server_async("neurag", "knowledge_status", {})
            out["neurag_engine"] = _json.loads(raw).get("engine", "?")
        except Exception:  # noqa: BLE001 — best-effort, il doctor non deve rompersi
            pass
    # Doctor esteso (passo 5): tier di TUTTI e 3 + se il cross-store è attivo.
    # Env reale > .env GM (stessa precedenza del runtime); best-effort sempre.
    try:
        from gray_matter import bridges as _b, cloud as _cloud
        saved = _cloud.read_env_file(_cloud.default_env_file())

        def _has(key: str) -> bool:
            return bool(os.environ.get(key, "").strip() or saved.get(key))

        shared = _has("TURSO_AUTH_TOKEN")
        out["tiers"] = {
            "neuron": "Turso (cloud)" if _has("TURSO_DATABASE_URL") and shared
                      else "local",
            "neurag": out.get("neurag_engine")
                      or ("Turso (cloud)" if _has("NEURAG_TURSO_DATABASE_URL")
                          and (shared or _has("NEURAG_TURSO_AUTH_TOKEN")) else "local"),
            # Il motore vero, non un'etichetta: "SQLite (local)" scritto a mano
            # lo diceva anche con bridges.py su Turso locale.
            "gm_bridges": _b.ENGINE_NAME,
        }
    except Exception:  # noqa: BLE001
        pass

    def _collab(name: str) -> bool:
        s = _registry.get_server(name)
        return bool(s and s.is_alive() and s.collaborative)

    # Cross-store = i bridge possono lavorare: entrambi gli store vivi e nel
    # pulse combinato (uno isolato/spento = niente collegamenti, per design).
    out["cross_store"] = _collab("neuron") and _collab("neurag")
    return out


def _norm(s: str) -> str:
    return " ".join(s.lower().split())


def _first_concept(text: str) -> str:
    # ponytail: parse the top keyword out of forgotten's text output (fragile; a
    # structured return would be cleaner — deferred to the persistence refactor).
    for line in text.splitlines():
        s = line.strip()
        if not s or s.endswith(":") or s.startswith(("Total:", "No ")):
            continue
        return s.split()[0]
    return ""


async def _maybe_flash(topic: str):
    """Flash v1/v2 — returns (note, concept). `concept` is the dormant keyword
    surfaced (or ""), which pulse uses to auto-persist a cross-store bridge (v3b).
    Fires at a topic shift, mid-band `near` selection, rate-limited by a min gap +
    a per-session per-concept cooldown."""
    global _last_topic, _calls_since_flash
    _calls_since_flash += 1
    shifted = _norm(topic) != _norm(_last_topic)
    _last_topic = topic
    if not shifted or _calls_since_flash < FLASH_MIN_GAP:
        return "", ""

    neuron = _registry.get_server("neuron")
    if not neuron or not neuron.is_alive():
        return "", ""
    forgotten = (await _call_server_async("neuron", "forgotten", {"threshold": 5, "near": topic, "top_n": 1})).strip()
    if not forgotten or forgotten.startswith("["):   # skip empties / "[neuron] error: ..."
        return "", ""
    key = forgotten[:80]
    if key in _flashed:                              # per-concept cooldown
        return "", ""
    _flashed.add(key)
    _calls_since_flash = 0
    _stats["flashes"] += 1
    return f"⚡ Flashback: {forgotten}", _first_concept(forgotten)


# ---------------------------------------------------------------------------
# IPC listener (background) — receives registrations, heartbeats
# ---------------------------------------------------------------------------

async def _recv_exact_async(loop, conn, n: int) -> "bytes | None":
    """Read exactly n bytes from a non-blocking socket, or None on short read.

    Suffisso `_async` non decorativo: si chiamava `_recv_exact` come l'omonima
    sincrona di cli.py e la copriva silenziosamente a livello di modulo."""
    buf = b""
    while len(buf) < n:
        try:
            chunk = await loop.sock_recv(conn, n - len(buf))
        except OSError:
            return None
        if not chunk:
            return None
        buf += chunk
    return buf


async def _recv_message(loop, conn) -> bytes:
    """One length-prefixed message: 4-byte big-endian length, then exactly that
    many bytes. Returns the payload (b'' on short read / bad frame). This is the
    fix for the old `data[4:]` single-recv assumption that broke on any message
    split across TCP segments."""
    header = await _recv_exact_async(loop, conn, 4)
    if header is None:
        return b""
    (length,) = struct.unpack("!I", header)
    if length <= 0 or length > 1_000_000:      # sanity guard vs junk/oversize
        return b""
    payload = await _recv_exact_async(loop, conn, length)
    return payload or b""


def _gm_answers_with_startup_grace(host: str, port: int,
                                   tries: int = 6, delay: float = 0.3) -> bool:
    """Repeated gm_answers: tolerates the bind→accept window of a GM starting
    on the same port (singleton race, 2026-08-25).

    Two daemons launched together: A binds but has not reached `listen` yet;
    B's single-shot probe timed out, B concluded "foreign process", moved to
    the next port and overwrote the rendezvous file → TWO live daemons,
    double writer on the graph. A GM answers as soon as it reaches accept; a
    foreign process NEVER answers, so the worst case is tries*delay on a dead
    port."""
    for _ in range(tries):
        if gm_answers(host, port):
            return True
        time.sleep(delay)
    return False


async def _ipc_listener(*, exit_on_busy: bool = True):
    """Background task: listens for incoming IPC connections (registrations, heartbeats).

    exit_on_busy: a daemon that finds :9876 taken is a duplicate and must die
    (SystemExit escapes asyncio). A stdio instance (main) must instead keep
    serving MCP without a listener — its managed workers don't need the port."""
    loop = asyncio.get_running_loop()
    # Singleton PRESERVATO ma porta DINAMICA: se su una porta candidata risponde
    # GIÀ un GM (probe `ping`), siamo un duplicato e moriamo. Se la porta è presa
    # da un processo ESTRANEO, si scala alla prima libera invece di non partire
    # mai. La porta scelta va nel rendezvous file, così i client la seguono.
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        if exit_on_busy:
            raise SystemExit(0)   # un GM è già vivo: duplicato → muori
        return                    # istanza stdio: serve MCP senza listener
    server_sock = None
    chosen = None
    for port in range(GRAY_MATTER_PORT, GRAY_MATTER_PORT + GRAY_MATTER_PORT_SPAN):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if os.name == "nt":
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((GRAY_MATTER_HOST, port))
        except OSError:
            s.close()
            # occupied: if a GM owns it we are a duplicate (die), else try the
            # next port. With startup grace: the single-shot probe loses the
            # race against a GM that bound an instant earlier (see helper).
            if _gm_answers_with_startup_grace(GRAY_MATTER_HOST, port):
                if exit_on_busy:
                    raise SystemExit(0)
                return
            if not exit_on_busy:
                # stdio mode: non cercare un'altra porta — salta l'ascolto IPC
                return
            continue
        server_sock, chosen = s, port
        break
    if server_sock is None:
        # nessuna porta libera nell'intervallo: non possiamo servire l'IPC
        if exit_on_busy:
            raise SystemExit(1)
        return
    # ADR-012 fase 2: chi fa il bind possiede l'identità dell'IPC. Chiave nuova
    # in RAM e canale per utente PRIMA di pubblicare la porta, così nessun
    # client trova la porta senza poter avere un token. Il segreto su file del
    # vecchio schema non autentica più niente: lo si cancella.
    _ipcauth.drop_legacy_token()
    _ipcauth.new_key()
    _ipcauth.serve(chosen)
    write_port_file(chosen)       # i client leggono qui la porta reale
    if chosen != GRAY_MATTER_PORT:
        print(f"gray-matter: porta preferita {GRAY_MATTER_PORT} occupata → uso {chosen}",
              file=sys.stderr)
    server_sock.listen(5)
    server_sock.setblocking(False)

    async def _handle_ipc_conn(conn) -> None:
        """One connection = one task (2026-08-25).

        Two bugs in the previous serial shape: (1) every request was awaited to
        completion — a long `call` (up to IPC_TOOL_TIMEOUT=60s) queued pings and
        heartbeats for EVERYONE, and the monitor marked servers dead that were
        merely waiting in line; (2) any exception outside
        (json.JSONDecodeError, KeyError) — a TypeError on a runaway field, a
        SQLite error in _build_stats — escaped the while loop, propagated
        through gather and KILLED the daemon. Dispatch can no longer kill the
        listener, and long calls run in parallel instead of blocking everyone
        (serialization stays in _call_server_async's per-server lock)."""
        global _last_call_time
        loop = asyncio.get_running_loop()
        try:
            try:
                conn.setblocking(False)
                data = await _recv_message(loop, conn)
                if not data:
                    return
                msg = json.loads(data.decode("utf-8"))
                action = msg.get("action")
                response = {}

                if action == "ping":
                    # Probe di identità: distingue un GM da un'app estranea
                    # sulla stessa porta (usato dal singleton + rendezvous).
                    # Volutamente SENZA token: il probe deve funzionare prima
                    # che chiunque conosca il segreto, e rivela solo "c'è un GM".
                    response = {"status": "ok", "gm": True}
                elif not _ipcauth.verify_request(str(msg.get("token", ""))):
                    # Ogni altra azione tocca la memoria (`call` esegue tool
                    # arbitrari, `knowledge_cmd` scrive nel vault). Loopback
                    # non è una barriera su una macchina multi-utente: serve un
                    # JWT rilasciato sul canale di QUESTO utente, firmato con la
                    # chiave di QUESTO avvio (ADR-012 fase 2).
                    response = {"error": "unauthorized"}
                elif action == "register":
                    _registry.register(
                        name=msg["name"],
                        tool_names=msg["tool_names"],
                        socket_path=msg["socket_path"],
                        pid=msg["pid"],
                    )
                    response = {"status": "ok", "message": f"Registered {msg['name']}"}
                elif action == "heartbeat":
                    ok = _registry.heartbeat(msg["name"])
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "unregister":
                    _registry.unregister(msg["name"])
                    response = {"status": "ok"}
                elif action == "isolate":
                    ok = _registry.set_collaborative(msg["name"], False)
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "collaborate":
                    ok = _registry.set_collaborative(msg["name"], True)
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "mode":
                    want = msg.get("mode") == "collaborate"
                    for s in _registry.all_servers():
                        s.collaborative = want
                    response = {"status": "ok"}
                elif action == "status":
                    response = _registry.to_dict()
                elif action == "stats":
                    response = _build_stats()
                elif action == "doctor":
                    response = await _build_doctor()
                elif action in ("call", "knowledge_cmd"):
                    # ONE shared worker set per machine: a stdio gateway does
                    # not spawn its own, it asks here. `knowledge_cmd` is the
                    # older NeuRAG-only spelling of the same thing, kept so an
                    # older CLI/GUI in the venv still works.
                    srv = "neurag" if action == "knowledge_cmd" else msg.get("server", "")
                    tool_name = msg.get("tool", "knowledge_status")
                    tool_args = msg.get("args", {})
                    # Every stdio gateway's worker calls land here: this is the
                    # counter `stats` shows, across sessions, until restart.
                    _tool_calls[tool_name] = _tool_calls.get(tool_name, 0) + 1
                    # ...and the daemon's idle clock. Only call_tool (stdio)
                    # moved it, and the daemon has no stdio: it fell asleep 600 s
                    # after start and never woke, so the doctor read "sleeping"
                    # on busy servers and on_sleep work could run once per life.
                    _last_call_time = time.time()
                    try:
                        result = await _call_server_async(srv, tool_name, tool_args)
                        response = {"result": result}
                    except Exception as e:
                        response = {"error": str(e)}
                elif action == "schemas":
                    # Same reason: the bootstrap must not spawn a local worker
                    # just to learn the tool list.
                    try:
                        response = {"result": await _fetch_tool_schemas(msg.get("server", ""))}
                    except Exception as e:
                        response = {"error": str(e)}
                elif action == "promote":
                    # CLS (§5.3): memory that proved itself becomes
                    # knowledge. Runs HERE, in the daemon, because it needs
                    # both workers — and because GM must never open someone
                    # else's vault itself (I3, and the single-writer lock).
                    response = await _do_promote(bool(msg.get("apply")))
                elif action == "gm-neuron":
                    tool_name = msg.get("tool")
                    tool_args = msg.get("args", {})
                    if not tool_name:
                        response = {"error": "Missing 'tool' parameter"}
                    else:
                        try:
                            result = await _call_server_async("neuron", tool_name, tool_args)
                            response = {"result": result}
                        except Exception as e:
                            response = {"error": str(e)}
                elif action == "gm-neurag":
                    tool_name = msg.get("tool")
                    tool_args = msg.get("args", {})
                    if not tool_name:
                        response = {"error": "Missing 'tool' parameter"}
                    else:
                        try:
                            result = await _call_server_async("neurag", tool_name, tool_args)
                            response = {"result": result}
                        except Exception as e:
                            response = {"error": str(e)}
                elif action == "shutdown":
                    response = {"status": "ok"}
                    # Graceful shutdown. On a non-blocking socket use the loop's
                    # sendall: the plain sync sendall could raise
                    # BlockingIOError and choke on the goodbye.
                    resp = json.dumps(response).encode("utf-8")
                    await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
                    conn.close()
                    server_sock.close()
                    # os._exit skips atexit AND the cleanup at the end of
                    # _run(), so the workers this daemon owns outlived it:
                    # orphan writers on the same graph files, with no final
                    # checkpoint. That is the accumulation pids.py was
                    # written to mop up — better not to create it.
                    # Same for a backup in flight: os._exit would cut the copy
                    # in half. Wait for it (bounded: a wedged disk must not
                    # make `stop` hang forever; the .tmp is swept next run).
                    from gray_matter import backup as _backup
                    if not await asyncio.to_thread(_backup.wait_idle, 120.0):
                        print("[gray-matter] shutdown: backup still running after 120s, "
                              "leaving its .tmp behind", file=sys.stderr)
                    _shutdown_workers()
                    os._exit(0)
                else:
                    response = {"error": f"Unknown action: {action}"}

                resp = json.dumps(response).encode("utf-8")
                await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
            except (json.JSONDecodeError, KeyError):
                return          # malformed request: no reply is possible
            except Exception as e:  # noqa: BLE001 — the daemon must not die for one request
                try:
                    resp = json.dumps({"error": f"internal error: {e!r}"}).encode("utf-8")
                    await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
                except OSError:
                    pass
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass

    while True:
        try:
            conn, addr = await loop.sock_accept(server_sock)
            asyncio.create_task(_handle_ipc_conn(conn))
        except OSError:
            await asyncio.sleep(0.1)


# ---------------------------------------------------------------------------
# Heartbeat monitor (background) — marks dead servers
# ---------------------------------------------------------------------------

async def _heartbeat_monitor():
    """Background task: check heartbeats, mark dead servers."""
    while True:
        await asyncio.sleep(HEARTBEAT_INTERVAL)
        now = time.time()
        for server in _registry.all_servers():
            if server.managed:
                continue   # worker-backed: liveness is the process, not a heartbeat
            if server.status == "alive" and (now - server.last_heartbeat) > HEARTBEAT_TIMEOUT:
                server.status = "dead"

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _init_options() -> InitializationOptions:
    """Handshake metadata for stdio mode. `capabilities` is a REQUIRED pydantic
    field — omitting it (as the old inline construction did) raises at the very
    first stdio startup, which daemon-only runs never exercised."""
    from mcp.server.lowlevel import NotificationOptions
    return InitializationOptions(
        server_name="gray-matter",
        server_version=__version__,
        capabilities=app.get_capabilities(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        ),
        instructions=GM_INSTRUCTIONS,
    )


def _ensure_daemon(wait: float = 5.0) -> bool:
    """Make sure the machine-wide worker owner exists; True if we can delegate.

    Without this the FIRST client still runs its own workers and only the second
    one would share — i.e. the common single-client case would keep paying the
    gigabyte and nothing would ever be shared.

    `wait` is a budget against the MCP handshake, which is blocked while we sit
    here: measured cold start to first `ping` is ~2 s (run_daemon opens the
    listener concurrently with `_bootstrap_subservers`, so the slow model load
    is NOT on this path). 5 s leaves headroom without risking a client-side
    timeout. Best-effort throughout: if it does not come up we run local
    workers, exactly as before.
    """
    if os.environ.get("GM_SHARED_WORKERS", "1") == "0":
        return False
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        return True
    try:
        _spawn_gray_matter()
    except Exception:  # noqa: BLE001 — never block the MCP handshake
        return False
    deadline = time.time() + wait
    while time.time() < deadline:
        if gm_answers(GRAY_MATTER_HOST, resolve_port()):
            return True
        time.sleep(0.3)
    return False


def main() -> None:
    """Run Gray-Matter as a stdio MCP server with background IPC listener."""
    _record_self("stdio")
    _reap_orphans()
    # Before any worker can be spawned locally: one shared set per machine.
    if _ensure_daemon():
        global _daemon_gone_until
        _daemon_gone_until = 0.0
    async def _run():
        # Start background tasks
        ipc_task = asyncio.create_task(_ipc_listener(exit_on_busy=False))
        hb_task = asyncio.create_task(_heartbeat_monitor())
        sleep_task = asyncio.create_task(_sleep_monitor())
        reap_task = asyncio.create_task(_reap_dead_workers())
        prewarm_task = asyncio.create_task(_prewarm_workers())

        # Gateway model: self-discover installed sub-servers as managed workers
        # (they no longer autoregister when the client launches only GM).
        await _bootstrap_subservers()

        # Start stdio MCP server
        from mcp.server.stdio import stdio_server
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream,
                write_stream,
                _init_options(),
            )

        # Cleanup
        ipc_task.cancel()
        hb_task.cancel()
        sleep_task.cancel()
        reap_task.cancel()
        prewarm_task.cancel()
        _shutdown_workers()

    asyncio.run(_run())

def auto_register_and_run(name: str, tool_names: list[str]) -> None:
    """Called by a server (Neuron, NeuRAG) on startup.

    Tries to register with existing Gray-Matter.
    If Gray-Matter is not running, spawns one first,
    then runs the server's own MCP main loop.
    """
    autoregister(name, tool_names)

    # Start heartbeat in background
    import threading
    def _heartbeat_loop():
        while True:
            time.sleep(HEARTBEAT_INTERVAL)
            _send_heartbeat(name)
    t = threading.Thread(target=_heartbeat_loop, daemon=True)
    t.start()


def _record_self(role: str) -> None:
    """Iscrive questo processo al registro dei PID (INSTALLER-UX §7).

    Best-effort e mai bloccante: senza registro la suite funziona lo stesso,
    è `doctor` che smette di poter dire "questi due sono rimasti indietro".
    """
    try:
        from gray_matter import pids as _pids
        _pids.record_self(role)
    except Exception:  # noqa: BLE001
        pass


def run_daemon() -> None:
    """Registry/orchestrator only: IPC listener (:9876) + monitors, NO stdio MCP.
    This is how Gray-Matter runs when started as a background daemon (autoregister
    or `gray-matter start`) — there's no MCP client to attach stdio to, so main()'s
    stdio_server() would just exit on a detached process."""
    global _IS_DAEMON
    _IS_DAEMON = True          # owns the workers: must never delegate to itself
    _record_self("daemon")
    _reap_orphans()

    async def _run():
        # Stessa self-discovery di main(): era cablata SOLO nel ramo stdio, così
        # un daemon avviato con `gray-matter start` (o spawnato da autoregister)
        # restava con il registro vuoto — `status` diceva "Servers: 0" e ogni
        # gm-neuron/gm-neurag moriva con "worker gave no response". I due rami
        # devono partire dallo stesso stato: è lo stesso gateway.
        #
        # In BACKGROUND, non awaited prima del listener: il bootstrap interroga
        # i worker (spawn del subprocess + caricamento del modello) e può durare
        # decine di secondi. Awaitarlo qui teneva la porta IPC chiusa per tutto
        # quel tempo: `gray-matter start` diceva "started" e un `doctor` subito
        # dopo rispondeva "not running" con connessione rifiutata. main() fa lo
        # stesso: crea il task del listener PRIMA di aspettare il bootstrap.
        boot = asyncio.create_task(_bootstrap_subservers())
        boot.add_done_callback(lambda t: t.cancelled() or t.exception())
        await asyncio.gather(
            _ipc_listener(),
            _heartbeat_monitor(),
            _sleep_monitor(),
            _reap_dead_workers(),
        )
    asyncio.run(_run())


if __name__ == "__main__":
    import sys
    if "--daemon" in sys.argv:
        run_daemon()
    else:
        main()
